<header class="t-header f js ac">
    <a class="f"  href="/tweets">
        <img width="" src="{{asset('assets/logo.png')}}" alt="" srcset="">
        <div class="t-brand"></div>

    </a>
    @auth

    <div class="menu" id="menu-toggler">Menu</div>

        @endauth
</header>
