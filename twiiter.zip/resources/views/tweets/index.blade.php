

<x-app>

        @include('_t-form')
        @include('_feed')


</x-app>


