<nav id="menu" class="t-nav f fc ast ">

    <div class="nav-links f fc js mb1">
        <a class="nav-link" href="/tweets">Home</a>
        <a class="nav-link" href="/explore">Explore</a>
    <a class="nav-link" href="/notifications">
        <span>Notifications</span>
        <?php if($count = Auth::user()->unreadNotifications->count()): ?>
            <span class="notifications-count">
                <?php echo e($count); ?>

            </span>
        <?php endif; ?>
    </a>

        <a class="nav-link" href="/users/<?php echo e(Auth::user()->uname); ?>">Profile</a>

        <?php if(auth()->guard()->check()): ?>

         <form class="f ac" method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>

                <button class="nav-link logout" type="submit">
                   Logout
                </button>
            </form>


    </div>
    <button id="tweetBtn"  class="btn btn-tweet nav-tweet" >Tweet a post</button>

    <?php endif; ?>
</nav>
<?php /**PATH C:\xampp\htdocs\twiiter\resources\views/_nav.blade.php ENDPATH**/ ?>