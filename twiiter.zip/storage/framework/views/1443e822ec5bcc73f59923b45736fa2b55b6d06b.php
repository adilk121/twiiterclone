<header class="t-header f js ac">
    <a class="f"  href="/tweets">
        <img width="" src="<?php echo e(asset('assets/logo.png')); ?>" alt="" srcset="">
        <div class="t-brand"></div>

    </a>
    <?php if(auth()->guard()->check()): ?>

    <div class="menu" id="menu-toggler">Menu</div>

        <?php endif; ?>
</header>
<?php /**PATH C:\xampp\htdocs\twiiter\resources\views/_header.blade.php ENDPATH**/ ?>