<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => []]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>



    <div class="notification f fc jc">

        <div class="unread">
            <?php $__currentLoopData = Auth::user()->unreadNotifications->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php if($notif->type == 'App\Notifications\FollowNotififcation'): ?>

            <form class="f jst ac" action="/notifications/<?php echo e($notif->id); ?>" method="post">
                <?php echo csrf_field(); ?>
                <button type="submit" class="f1">
                    <div class="notification-card unread  f ac js">


                        <?php echo e($notif->data['follower']); ?>

                        Followed you
                        <small>
                            &nbsp;
                            <?php echo e($notif->created_at->diffForHumans()); ?>

                        </small>
                    </div>
                </button>
            </form>

            <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


            <div class="read">
                <?php $__currentLoopData = Auth::user()->readNotifications->sortByDesc('read_at');; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($notif->type == 'App\Notifications\FollowNotififcation'): ?>

                <div class="notification-card read f1 f ac js">


                    <?php echo e($notif->data['follower']); ?>

                    Followed you
                    <small>
                        &nbsp;
                        <?php echo e($notif->created_at->diffForHumans()); ?>

                    </small>
                </div>

                <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>


        
    </div>



 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\twiiter\resources\views/notifications/index.blade.php ENDPATH**/ ?>