<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => []]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>



    <div class="explore f fc jc">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="user-card f1 f ac jb">
                    <div class="f ac js">

                        <img class="t-avatar avatar" src=<?php echo e($user->avatar); ?> alt="">

                            <a href="/users/<?php echo e($user->uname); ?>">
                                <?php echo e($user->name); ?>

                                <small><?php echo e('@'.$user->uname); ?></small>
                            </a>

                    </div>

                        <form action="<?php echo e($user->path('follow')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                    class="btn user-btn <?php echo e(Auth::user()->following($user) ? 'btn-tweet-red' : 'btn-tweet'); ?> ">
                                    <?php echo e(Auth::user()->following($user) ? 'Unfollow' : 'Follow'); ?>

                            </button>
                        </form>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php echo e($users->links()); ?>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\twiiter\resources\views/explore/index.blade.php ENDPATH**/ ?>