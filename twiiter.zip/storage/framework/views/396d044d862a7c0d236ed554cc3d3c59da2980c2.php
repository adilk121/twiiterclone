<form class="form tsm" method="POST" action="<?php echo e(route('user-profile-information.update')); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <?php if(session()->has('profile-update')): ?>
    <div class="group">
        <div class="msg-success tc">
            <?php echo e(session()->get('profile-update')); ?>

        </div>
    </div>
    <?php endif; ?>

    <div class="group f ac jb">
        <label class="label f1">Username</label>
        <input class="f1" type="text" name="uname" value="<?php echo e(old('uname') ?? auth()->user()->uname); ?>" required autofocus autocomplete="name" />

    </div>
    <?php $__errorArgs = ['uname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="group f ac jc">
        <div class="error tc"><?php echo e($message); ?></div>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <div class="group f ac jb">
        <label class="label f1"><?php echo e(__('Name')); ?></label>
        <input class="f1" type="text" name="name" value="<?php echo e(old('name') ?? auth()->user()->name); ?>" required autofocus autocomplete="name" />
    </div>
    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="group f ac jc">
        <div class="error tc"><?php echo e($message); ?></div>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <div class="group f ac jb">
        <label class="label f1"><?php echo e(__('Email')); ?></label>
        <input class="f1" type="email" name="email" value="<?php echo e(old('email') ?? auth()->user()->email); ?>" required autofocus />
    </div>
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="group f ac jc">
        <div class="error tc"><?php echo e($message); ?></div>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <div  class="group f ac jb">
        <label class="label f1">Avatar</label>
        <input class="f1" type="file" name="avatar" />
    </div>

    <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="group f ac jc">
        <div class="error tc"><?php echo e($message); ?></div>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <div  class="group f ac jb">
        <label class="label f1"><?php echo e(__('Current Password')); ?></label>
        <input class="f1" type="password" name="old_password" required autocomplete="odl_password" />
    </div>
    <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="group f ac jc">
        <div class="error tc"><?php echo e($message); ?></div>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="group f ac jb">
        <button class="btn btn-auth tsm" type="submit">
            <?php echo e(__('Update Profile')); ?>

        </button>


    </div>


</form>

<?php /**PATH C:\xampp\htdocs\twiiter\resources\views/profile/update-profile-information-form.blade.php ENDPATH**/ ?>