<div class="tweet f as js">
    <img class="t-avatar avatar" src=<?php echo e($tweet->user->avatar); ?> alt="">

    <div class="t-content">
        <div class="name">
            <a href="/users/<?php echo e($tweet->user->uname); ?>">
                <?php echo e($tweet->user->name); ?>


            </a>

        </div>
        <div class="body">
            <?php echo e($tweet->body); ?>

        </div>
        <?php if($images = $tweet->image): ?>
            <div class="t-images f fw">
                <?php if(count($images)>1): ?>
                <i id="slide-backward" class="fa fa-arrow-left slide-backward ">  </i>
                <i id="slide-forward" class="fa fa-arrow-right slide-forward"></i>

                <?php endif; ?>
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="image  f ac jc">
                        <img class="img" src=<?php echo e($image); ?> alt="">
                    </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        <?php endif; ?>
       
    <div class="react f ac">
        <form action="/tweets/<?php echo e($tweet->id); ?>/like" method="post">
            <?php echo csrf_field(); ?>
        <button type="submit" class=<?php echo e($tweet->liked(Auth::user()) ? 'like' : ''); ?>>
            <i class="fa fa-thumbs-up "></i>
                <span><?php echo e($tweet->likesCount() ?: ''); ?></span>

            </button>
        </form>
        <form action="/tweets/<?php echo e($tweet->id); ?>/dislike" method="post">
            <?php echo csrf_field(); ?>
            <button type="submit" class=<?php echo e($tweet->liked(Auth::user(),false) ? 'dislike' :''); ?>>
                <i class="fa fa-thumbs-down"></i>
                <span><?php echo e($tweet->likesCount(false) ?: ''); ?> </span>
            </button>
        </form>
    </div>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\twiiter\resources\views/_tweet.blade.php ENDPATH**/ ?>