<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.master','data' => []]); ?>
<?php $component->withName('master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="container wf hf">
            <?php if(session('status')): ?>
            <div class="status">
                <?php echo e(session('status')); ?>

            </div>
             <?php endif; ?>



        <form class="form sign-form c" method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>

            <div class="group f ac jb">
                <label  ><?php echo e(__('Email')); ?></label>
                <input class="control" type="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus />
            </div>

            <div class="group f ac jb">
                <label  ><?php echo e(__('Password')); ?></label>
                <input class="control" type="password" name="password" required autocomplete="current-password" />
            </div>

            <div class="group f ac js">
                <label  ><?php echo e(__('Remember me')); ?></label>
                <input class="control" type="checkbox" name="remember">
            </div>

            <?php if(Route::has('password.request')): ?>
                <div class="group f jc">
                    <a class="link c" href="<?php echo e(route('password.request')); ?>">
                        <?php echo e(__('Forgot your password?')); ?>

                    </a>
                </div>

            <?php endif; ?>
            <div class="group f jc">
                <a class="link c" href="/register">
                    New here ? Sign up
                </a>
            </div>
            <div class="group f jc">
                <button class="btn btn-auth" type="submit">
                <?php echo e(__('Login')); ?>

                </button>
            </div>

        </form>


        <?php if($errors->any()): ?>
            <div class="errors card c">
                <div class="card-head"><?php echo e(__('Whoops! Something went wrong.')); ?></div>

                <ul class="card-body ">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="error"><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\twiiter\resources\views/auth/login.blade.php ENDPATH**/ ?>