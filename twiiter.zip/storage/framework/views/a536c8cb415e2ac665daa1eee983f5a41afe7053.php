<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.master','data' => []]); ?>
<?php $component->withName('master'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>


   <div class="container wf hf">


        <form class="form sign-form c" method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>

            <div class="group f jb ac">
                <label><?php echo e(__('Name')); ?></label>
                <input type="text" name="name" value="<?php echo e(old('name')); ?>" required autofocus autocomplete="name"  />
            </div>
            <div class="group f jb ac">
                <label><?php echo e(__('User Name')); ?></label>
                <input type="text" name="uname" value="<?php echo e(old('uname')); ?>" required autofocus autocomplete="uname" />
            </div>
            <div class="group f jb ac">
                <label><?php echo e(__('Email')); ?></label>
                <input type="email" name="email" value="<?php echo e(old('email')); ?>" required />
            </div>

            <div class="group f jb ac">
                <label><?php echo e(__('Password')); ?></label>
                <input type="password" name="password" required autocomplete="new-password" />
            </div>

            <div class="group f jb ac">
                <label><?php echo e(__('Confirm Password')); ?></label>
                <input type="password" name="password_confirmation" required autocomplete="new-password" />
            </div>

            <div class="group f jc mt2">
                    <a class="link " href="<?php echo e(route('login')); ?>">
                        <?php echo e(__('Already registered? Sign In')); ?>

                    </a>
            </div>

            <div class="group f jc">
                <button class="btn btn-auth" type="submit">
                    <?php echo e(__('Register')); ?>

                </button>
            </div>
        </form>

        <?php if($errors->any()): ?>
            <div class="errors c card">
                <div class="card-head "><?php echo e(__('Whoops! Something went wrong.')); ?></div>

                <ul class="card-body  ">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="error"><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
   </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\twiiter\resources\views/auth/register.blade.php ENDPATH**/ ?>