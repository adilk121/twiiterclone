<aside class="t-friends f fc ast js">
    <h3>Following</h3>

        <?php $__empty_1 = true; $__currentLoopData = auth()->user()->follows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a class="friend" href="<?php echo e($user->path()); ?>">
            <img class="avatar" src=<?php echo e($user->avatar); ?> width="35px" alt="" srcset="">
            <div class="name">

                <?php echo e($user->name); ?>

            </div>
        </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="friend">
            <h5>
                <a href="/explore">Start following people</a>
            </h5>
        </div>


        <?php endif; ?>


</aside>
<?php /**PATH C:\xampp\htdocs\twiiter\resources\views/_friends.blade.php ENDPATH**/ ?>