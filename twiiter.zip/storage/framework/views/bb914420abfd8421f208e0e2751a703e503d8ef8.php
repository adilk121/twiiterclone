
    <div class="cover">

    <div class="cover-thumb f ac">

        <img src=<?php echo e($user->cover); ?> />
    </div>

        <div class="cover-content f fc ac">
            <div class="user-info f ae jb">

                <a class="user-name f fc" href="<?php echo e($user->path()); ?>">

                    <div><?php echo e($user->name); ?></div>

                    <small>
                       <?php echo e($user->uname); ?>

                    </small>
                </a>

                <img class="user-avatar avatar" src=<?php echo e($user->avatar); ?> />

                <div class="user-param f ac je">
                    <?php if(Auth::user()->id == $user->id): ?>
                        <button class="btn user-btn btn-grey">
                            <a href="<?php echo e($user->path('edit')); ?>">
                                Edit
                            </a>
                        </button>

                    <?php else: ?>



                            <form action="<?php echo e($user->path('follow')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <button type="submit"
                                        class="btn user-btn <?php echo e(Auth::user()->following($user) ? 'btn-tweet-red' : 'btn-tweet'); ?> ">
                                        <?php echo e(Auth::user()->following($user) ? 'Unfollow' : 'Follow'); ?>

                                </button>
                            </form>



                    <?php endif; ?>


                </div>
            </div>
            <div class="user-bio">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatem hic quas eius perspiciatis nesciunt! Illum, nemo! Molestias praesentium ad, ipsum id maxime reprehenderit suscipit sequi sunt!
            </div>
        </div>

    </div>
<?php /**PATH C:\xampp\htdocs\twiiter\resources\views/_cover.blade.php ENDPATH**/ ?>