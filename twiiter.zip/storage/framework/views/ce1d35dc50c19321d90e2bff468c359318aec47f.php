<form class="form tsm" method="POST" action="<?php echo e(route('user-password.update')); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <?php if(session()->has('password-update')): ?>
    <div class="group">
        <div class="msg-success tc">
            <?php echo e(session()->get('password-update')); ?>

        </div>
    </div>
    <?php endif; ?>
    <div  class="group f ac jb">
        <label class="label f1"><?php echo e(__('Current Password')); ?></label>
        <input class="f1" type="password" name="current_password" required autocomplete="current-password" />
    </div>
    <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="group f ac jc">
        <div class="error tc"><?php echo e($message); ?></div>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="group f ac jb">
        <label class="label f1"><?php echo e(__('Password')); ?></label>
        <input class="f1" type="password" name="password" required autocomplete="new-password" />
    </div>
    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="group f ac jc">
        <div class="error tc"><?php echo e($message); ?></div>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="group f ac jb">
        <label class="label f1"><?php echo e(__('Confirm Password')); ?></label>
        <input class="f1" type="password" name="password_confirmation" required autocomplete="new-password" />
    </div>
    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="group f ac jc">
        <div class="error tc"><?php echo e($message); ?></div>

    </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="group f ac jb">
        <button class="btn btn-auth tsm" type="submit">
            <?php echo e(__('Save')); ?>

        </button>


    </div>


</form>

<?php /**PATH C:\xampp\htdocs\twiiter\resources\views/profile/update-password-form.blade.php ENDPATH**/ ?>