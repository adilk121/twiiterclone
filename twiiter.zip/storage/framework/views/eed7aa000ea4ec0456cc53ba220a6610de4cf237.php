<?php if($paginator->hasPages()): ?>



    <nav role="navigation" aria-label="<?php echo e(__('Pagination Navigation')); ?>" class="pagination f ac jb">
        <div class="f ja ac f1">
            <?php if($paginator->onFirstPage()): ?>
                <span class="item f ac">
                    <?php echo __('pagination.previous'); ?>

                </span>
            <?php else: ?>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="link f ac">
                    <?php echo __('pagination.previous'); ?>

                </a>
            <?php endif; ?>
            <div class="info">



                    <span class="font-medium"><?php echo e($paginator->firstItem()); ?></span>
                    <?php echo __('to'); ?>

                    <span class="font-medium"><?php echo e($paginator->lastItem()); ?></span>
                    <?php echo __('of'); ?>

                    <span class="font-medium"><?php echo e($paginator->total()); ?></span>


            </div>
            <?php if($paginator->hasMorePages()): ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="link f ac ">
                    <?php echo __('pagination.next'); ?>

                </a>
            <?php else: ?>
                <span class="item f ac ml-3">
                    <?php echo __('pagination.next'); ?>

                </span>
            <?php endif; ?>
        </div>

    </nav>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\twiiter\resources\views/vendor/pagination/tailwind.blade.php ENDPATH**/ ?>